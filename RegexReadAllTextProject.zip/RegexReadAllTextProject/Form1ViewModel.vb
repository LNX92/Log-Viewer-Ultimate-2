﻿Imports DevExpress.Mvvm.DataAnnotations

<POCOViewModel()>
Public Class Form1ViewModel

End Class
